"""
智能电影评论分析平台 - Flask主应用

功能模块：
- 评论管理（CRUD）
- 数据分析（词云、情感、聚类）
- 智能报告生成
- 对话式问答

作者：智能评论分析平台开发团队
版本：v1.0.0
"""

import os
import time
from flask import Flask, render_template, request, jsonify
from flask_cors import CORS
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__, static_folder='static', static_url_path='/static')

# 启用CORS跨域支持，允许前端从不同域名访问API
CORS(app)

# 配置应用密钥，用于会话加密等安全功能
app.secret_key = os.getenv('SECRET_KEY', 'dev-secret-key-change-in-production')

# 禁用模板缓存（开发环境）
app.config['TEMPLATES_AUTO_RELOAD'] = True

# 设置静态文件缓存时间为0（开发环境）
app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 0


def preload_models():
    """预加载所有模型，避免首次请求超时"""
    print("\n" + "="*60)
    print("开始预加载模型...")
    print("="*60)
    
    # 预加载情感分析模型
    try:
        from nlp.sentiment_analyzer import get_trained_model
        print("\n1. 预加载情感分析模型...")
        start = time.time()
        get_trained_model()
        print(f"   完成! 耗时: {time.time() - start:.2f}秒")
    except Exception as e:
        print(f"   失败: {e}")
    
    # 预加载Sentence-BERT模型
    try:
        from nlp.semantic_vectorizer import get_vectorizer
        print("\n2. 预加载Sentence-BERT模型...")
        start = time.time()
        vectorizer = get_vectorizer()
        # 触发模型加载
        vectorizer.encode(['test'])
        print(f"   完成! 耗时: {time.time() - start:.2f}秒")
    except Exception as e:
        print(f"   失败: {e}")
    
    print("\n" + "="*60)
    print("预加载完成！")
    print("="*60 + "\n")


@app.route('/')
def index():
    """
    首页路由
    """
    return render_template('index.html')


@app.route('/api/comments', methods=['GET'])
def get_comments_api():
    """
    获取评论列表API
    
    功能：根据筛选条件获取评论数据
    
    Query参数：
        target (str, optional): 电影名称筛选
    
    返回：JSON格式的评论列表
    
    示例请求：
        GET /api/comments
        GET /api/comments?target=Your Name
    """
    try:
        from data_loader import load_comments
        
        target = request.args.get('target')
        df = load_comments(target)
        
        # 转换为字典列表
        # to_dict('records') 将DataFrame转换为字典列表
        comments = df.to_dict('records')
        
        # 返回JSON响应
        return jsonify({
            'status': 'success',
            'data': comments,
            'count': len(comments)
        })
        
    except FileNotFoundError as e:
        # 数据文件不存在
        return jsonify({
            'status': 'error',
            'message': f"数据文件不存在: {str(e)}"
        }), 404
        
    except Exception as e:
        # 发生其他错误时返回错误信息
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500


@app.route('/api/comments', methods=['POST'])
def add_comment_api():
    """
    发布新评论API
    
    功能：添加新的电影评论到CSV文件
    
    请求体（JSON）：
        text (str): 评论文本内容
        target (str): 电影名称
        rating (int, optional): 评分，1-5分，默认3分
    
    返回：JSON格式的操作结果
    
    示例请求：
        POST /api/comments
        Content-Type: application/json
        {
            "text": "这部电影太棒了！",
            "target": "Your Name",
            "rating": 5
        }
    """
    # 获取请求体中的JSON数据
    data = request.get_json()
    
    # 提取评论内容，添加默认值防止为空
    text = data.get('text', '').strip()
    target = data.get('target', '').strip()
    rating = data.get('rating', 3)
    
    # 参数验证
    if not text or not target:
        return jsonify({
            'status': 'error',
            'message': '评论内容和电影名称不能为空'
        }), 400
    
    try:
        from data_loader import add_comment
        
        new_id = add_comment(text, target, rating)
        
        return jsonify({
            'status': 'success',
            'message': '评论发布成功',
            'data': {
                'id': new_id,
                'text': text,
                'target': target,
                'rating': rating
            }
        }), 201
        
    except Exception as e:
        # 发生错误时返回错误信息
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500


@app.route('/api/targets', methods=['GET'])
def get_targets_api():
    """
    获取所有电影名称列表API
    
    功能：获取CSV文件中所有已存在的电影名称
    
    返回：JSON格式的电影名称数组
    
    示例响应：
        {
            "status": "success",
            "data": ["Big Fish and Begonia", "Your Name", ...]
        }
    """
    try:
        from data_loader import get_targets
        
        targets = get_targets()
        
        return jsonify({
            'status': 'success',
            'data': targets
        })
        
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500


@app.route('/api/analysis/wordcloud', methods=['GET'])
def generate_wordcloud():
    """
    生成词云API
    
    功能：对评论进行分词和词频统计，生成词云图片
    
    Query参数：
        target (str, optional): 电影名称，默认为釜山行
    
    返回：JSON格式，包含词云图片路径和关键词统计
    
    算法流程：
        1. 从CSV文件获取评论文本
        2. 使用jieba进行中文分词
        3. 过滤停用词
        4. 统计词频
        5. 生成词云图片
        6. 返回前20个高频词
    """
    from nlp.text_processor import generate_wordcloud, extract_keywords
    
    # 获取目标电影参数，默认是釜山行
    target = request.args.get('target', '釜山行')
    
    try:
        # 生成词云图片，返回图片URL
        wordcloud_path = generate_wordcloud(target)
        
        # 提取Top 20关键词及频次
        keywords = extract_keywords(target, top_n=20)
        
        return jsonify({
            'status': 'success',
            'wordcloud_path': wordcloud_path,
            'keywords': keywords
        })
        
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500


@app.route('/api/analysis/sentiment', methods=['GET'])
def analyze_sentiment():
    """
    情感分析API
    
    功能：对评论进行情感分类分析
    
    Query参数：
        target (str, optional): 电影名称，默认为釜山行
    
    返回：JSON格式，包含情感分布统计
    
    算法说明：
        - 使用Sentence-BERT进行文本向量化
        - 使用逻辑回归分类器进行情感预测
        - 将评论分为正面/负面/中性三类
    """
    from nlp.sentiment_analyzer import analyze_comments
    
    # 获取目标电影参数，默认是釜山行
    target = request.args.get('target', '釜山行')
    
    try:
        # 执行情感分析
        result = analyze_comments(target)
        return jsonify(result)
        
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500


@app.route('/api/analysis/clusters', methods=['GET'])
def api_analyze_clusters():
    """主题聚类API（使用Sentence-BERT深度语义向量化和t-SNE降维）"""
    
    target = request.args.get('target', '釜山行')
    
    try:
        from nlp.cluster_analyzer import analyze_clusters
        
        result = analyze_clusters(
            target=target, 
            n_clusters=5,
            max_samples=100000
        )
        result['target'] = target
        result['note'] = '已使用Sentence-BERT深度语义聚类'
        
        return jsonify(result)
        
    except Exception as e:
        print(f"聚类分析失败: {e}")
        # 返回错误信息，由前端处理显示
        return jsonify({
            'status': 'error',
            'message': f'聚类分析失败: {str(e)}',
            'target': target
        }), 500


@app.route('/api/analysis/report', methods=['POST'])
def api_generate_report():
    """生成分析报告API（任务4：对话式报告生成）"""
    
    try:
        from llm.report_generator import generate_report
        
        data = request.get_json()
        target = data.get('target', '釜山行')
        
        report = generate_report(target)
        
        return jsonify({
            'status': 'success',
            'report': report,
            'target': target
        })
        
    except Exception as e:
        print(f"报告生成失败: {e}")
        return jsonify({
            'status': 'error',
            'message': f'报告生成失败: {str(e)}',
            'target': target
        }), 500


@app.route('/api/experiment/sentiment', methods=['POST'])
def run_sentiment_experiment():
    """
    运行情感分类模型对比实验API（任务2：模型性能比较）

    返回：JSON格式，包含4种模型的对比结果
    """
    import pandas as pd
    import numpy as np
    from sklearn.naive_bayes import GaussianNB
    from sklearn.svm import SVC
    from sklearn.linear_model import LogisticRegression
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.model_selection import train_test_split
    from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score

    try:
        from data_loader import load_comments

        # 加载数据
        df = load_comments()

        # 转换标签
        sentiment_mapping = {'negative': 0, 'neutral': 1, 'positive': 2}
        df['label'] = df['sentiment'].map(sentiment_mapping)
        df = df.dropna(subset=['label'])
        df['label'] = df['label'].astype(int)

        X_text = df['text'].values
        y = df['label'].values

        # 使用Sentence-BERT向量化
        print("\n使用Sentence-BERT进行文本向量化...")
        from nlp.semantic_vectorizer import get_vectorizer
        vectorizer = get_vectorizer()
        X = vectorizer.encode(X_text.tolist())

        # 划分数据集
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42
        )

        # 定义模型
        models = {
            '高斯朴素贝叶斯': GaussianNB(),
            'SVM': SVC(kernel='linear', C=1.0, class_weight='balanced', random_state=42),
            '逻辑回归': LogisticRegression(max_iter=1000, class_weight='balanced', random_state=42),
            '随机森林': RandomForestClassifier(n_estimators=100, class_weight='balanced', random_state=42)
        }

        results = []
        best_model = None
        best_accuracy = 0

        for name, model in models.items():
            model.fit(X_train, y_train)
            y_pred = model.predict(X_test)

            accuracy = accuracy_score(y_test, y_pred)
            f1_macro = f1_score(y_test, y_pred, average='macro')
            f1_weighted = f1_score(y_test, y_pred, average='weighted')
            precision = precision_score(y_test, y_pred, average='weighted', zero_division=0)
            recall = recall_score(y_test, y_pred, average='weighted', zero_division=0)

            results.append({
                '模型': name,
                '准确率': accuracy,
                'F1(Macro)': f1_macro,
                'F1(Weighted)': f1_weighted,
                '精确率': precision,
                '召回率': recall
            })

            if accuracy > best_accuracy:
                best_accuracy = accuracy
                best_model = name

        # 分析错误案例（任务2：错误案例分析）
        errors = []
        for i, (true, pred) in enumerate(zip(y_test, models[best_model].predict(X_test))):
            if true != pred:
                errors.append({
                    'text': X_text.tolist()[X_train.shape[0]+i],
                    'true_label': ['负面', '中性', '正面'][true],
                    'pred_label': ['负面', '中性', '正面'][pred]
                })

        # 保存错误案例
        os.makedirs('output', exist_ok=True)
        errors_df = pd.DataFrame(errors)
        errors_df.to_csv('output/sentiment_errors.csv', index=False, encoding='utf-8')

        return jsonify({
            'status': 'success',
            'comparison': results,
            'best_model': best_model,
            'best_accuracy': best_accuracy,
            'error_count': len(errors)
        })

    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500


@app.route('/api/chat', methods=['POST'])
def chat():
    """
    智能对话API - 使用LLM
    """
    data = request.get_json()
    message = data.get('message', '')
    target = data.get('target', '釜山行')
    
    if not message:
        return jsonify({
            'status': 'error',
            'message': '问题内容不能为空'
        }), 400
    
    try:
        from openai import OpenAI
        
        client = OpenAI(
            api_key=os.getenv('DEEPSEEK_API_KEY', ''),
            base_url=os.getenv('DEEPSEEK_API_URL', 'https://api.deepseek.com')
        )
        
        # 从实际分析API获取实时数据
        from nlp.sentiment_analyzer import analyze_comments
        from nlp.cluster_analyzer import analyze_clusters
        
        sentiment_data = analyze_comments(target)
        cluster_data = analyze_clusters(target=target, n_clusters=5, max_samples=100000)
        
        analysis_context = f"""

## 情感分析结果
- 正面评论: {sentiment_data.get('positive', {}).get('count', 0)}条 ({sentiment_data.get('positive', {}).get('percentage', 0)}%)
- 负面评论: {sentiment_data.get('negative', {}).get('count', 0)}条 ({sentiment_data.get('negative', {}).get('percentage', 0)}%)
- 中性评论: {sentiment_data.get('neutral', {}).get('count', 0)}条 ({sentiment_data.get('neutral', {}).get('percentage', 0)}%)

## 主题聚类结果
"""
        
        for cluster in cluster_data.get('clusters', []):
            cluster_id = cluster.get('cluster_id', 0)
            topic_label = cluster_data.get('topic_labels', {}).get(str(cluster_id), f'主题{cluster_id}')
            keywords = cluster.get('keywords', [])
            size = cluster.get('size', 0)
            samples = cluster.get('samples', [])
            
            analysis_context += f"""### {topic_label} ({size}条评论)
- 关键词: {', '.join(keywords[:5])}
"""
            if samples:
                analysis_context += "- 示例评论:\n"
                for sample in samples[:2]:
                    analysis_context += f"  * \"{sample[:50]}...\"\n"
                analysis_context += "\n"
        
        system_prompt = f"""
你是一个专业的电影评论分析助手。请根据提供的分析数据回答用户问题。

分析目标: {target or '所有电影评论'}

要求:
1. 用中文清晰准确地回答
2. 适当引用具体评论示例
3. 讨论主题时参考聚类关键词
4. 如果没有相关信息，明确说明
5. 保持对话连贯性
6. 专注于提供数据驱动的洞察

--- 分析数据 ---
{analysis_context}
--- 分析数据结束 ---
"""
        
        messages = [{"role": "system", "content": system_prompt}]
        messages.append({"role": "user", "content": message})
        
        response = client.chat.completions.create(
            model="deepseek-v4-flash",
            messages=messages,
            max_tokens=3000,
            temperature=0.7
        )
        
        answer = response.choices[0].message.content
        
        if not answer:
            answer = '未能获取到响应内容'
        
        return jsonify({
            'status': 'success',
            'response': answer,
            'target': target,
            'used_analysis': True
        })
    
    except Exception as e:
        print(f"LLM调用失败: {e}")
        return jsonify({
            'status': 'error',
            'message': f'对话失败: {str(e)}',
            'target': target,
            'note': '请检查LLM API密钥配置是否正确'
        }), 500


@app.errorhandler(404)
def not_found(error):
    """
    404错误处理器
    
    功能：处理页面不存在的情况
    """
    return jsonify({
        'status': 'error',
        'message': '请求的资源不存在'
    }), 404


@app.errorhandler(500)
def internal_error(error):
    """
    500错误处理器
    
    功能：处理服务器内部错误
    """
    return jsonify({
        'status': 'error',
        'message': '服务器内部错误，请稍后重试'
    }), 500


if __name__ == '__main__':
    """
    应用入口
    
    启动Flask开发服务器
    
    配置说明：
        - host='127.0.0.1': 只允许本地访问
        - port=5000: 监听5000端口
        - debug=True: 开启调试模式（代码修改自动重启）
    
    生产环境部署建议：
        - 使用Gunicorn或uWSGI
        - 关闭debug模式
        - 配置反向代理（Nginx）
    """
    # 获取配置参数，支持环境变量覆盖
    host = os.getenv('FLASK_HOST', '127.0.0.1')
    port = int(os.getenv('FLASK_PORT', 5000))
    debug = os.getenv('FLASK_DEBUG', '1') == '1'
    
    # 预加载模型（避免首次请求超时）
    preload_models()
    
    # 启动Flask应用
    app.run(
        host=host,
        port=port,
        debug=debug
    )
