# 基于深度学习的电影评论情感分析与主题发现系统

## 项目简介

本项目是一个基于深度学习的电影评论分析平台，集成了情感分类、主题聚类和智能报告生成三大核心功能。采用Sentence-BERT进行深度语义向量化，使用K-Means算法进行无监督主题聚类，并通过大语言模型（DeepSeek）生成多维分析报告。

---

## 1. 运行环境

### 操作系统
- Windows 10/11
- Linux (Ubuntu 20.04+)
- macOS

### Python版本
- Python 3.9+

### 依赖库

```bash
# 核心依赖
flask>=2.0.0
flask-cors>=3.0.0

# 数据处理
numpy>=1.21.0
pandas>=1.3.0

# 机器学习
scikit-learn>=1.0.0

# 深度学习语义向量化
sentence-transformers>=2.2.0

# 大语言模型
openai>=1.0.0

# 环境变量管理
python-dotenv>=0.19.0

# 中文分词
jieba>=0.42.0

# 数据可视化
matplotlib>=3.4.0
wordcloud>=1.8.0

# t-SNE降维
tsne>=1.0.0
```

---

## 2. 数据集获取方式

### 2.1 数据来源

本项目使用的数据集来自 **豆瓣电影短评数据集**：

| 属性 | 详情 |
|------|------|
| **数据集名称** | Douban Movie Short Comments Dataset V2 |
| **来源** | Kaggle |
| **下载地址** | https://www.kaggle.com/utmhikari/doubanmovieshortcomments |
| **数据来源** | 豆瓣电影 |
| **原始规模** | 28部电影，超70万用户，超200万条评分/评论数据 |

### 2.2 数据加工处理

原始数据集经过以下处理：
1. 去重并整理成与MovieLens兼容的格式
2. 进行脱敏操作，以保护用户隐私
3. 选取其中两部电影进行分析：《釜山行》和《大鱼海棠》

### 2.3 项目使用数据

项目已处理的数据文件：
- 位置：`data/processed_comments.csv`
- 数量：6000条处理后的电影评论

### 2.4 数据集说明

| 字段 | 说明 |
|------|------|
| id | 评论唯一标识 |
| text | 评论文本内容 |
| rating | 用户评分（1-5分） |
| target | 电影英文名称 |
| sentiment | 情感标签（positive/negative/neutral） |

### 2.5 情感分布

| 情感类型 | 数量 | 占比 |
|----------|------|------|
| 正面评论 | 2000 | 33.3% |
| 中性评论 | 2000 | 33.3% |
| 负面评论 | 2000 | 33.3% |

### 2.6 覆盖电影

- 《釜山行》（Train to Busan）
- 《大鱼海棠》（Big Fish and Begonia）

---

## 3. 运行步骤

### 3.1 环境配置

#### 步骤1：克隆或下载项目
```bash
git clone <repository_url>
cd <project_directory>
```

#### 步骤2：创建虚拟环境（推荐）
```bash
python -m venv venv

# Windows激活
venv\Scripts\activate

# Linux/macOS激活
source venv/bin/activate
```

#### 步骤3：安装依赖
```bash
pip install -r requirements.txt
```

#### 步骤4：配置环境变量
创建 `.env` 文件，配置以下内容：

```env
# DeepSeek API配置（必需）
DEEPSEEK_API_KEY=your_api_key_here
DEEPSEEK_API_URL=https://api.deepseek.com

# Flask密钥（可选）
SECRET_KEY=your_secret_key_here
```

**获取API Key步骤**：
1. 访问 [DeepSeek开放平台](https://platform.deepseek.com/)
2. 注册账号并登录
3. 进入API Keys页面
4. 创建新的API Key
5. 将API Key复制到`.env`文件

### 3.2 启动服务

#### 步骤1：确保数据文件存在
```bash
ls data/
# 应该看到 processed_comments.csv 文件
```

#### 步骤2：启动Flask应用
```bash
python app.py
```

服务器启动后会显示：
```
预加载模型中...
预加载完成！
* Running on http://127.0.0.1:5000
```

#### 步骤3：访问Web界面
打开浏览器，访问：`http://localhost:5000`

### 3.3 预期输出

#### 功能1：评论管理
- ✅ 评论列表展示
- ✅ 按电影筛选
- ✅ 按情感类型筛选

#### 功能2：数据分析
- ✅ 情感分布饼图（正面/中性/负面）
- ✅ 高频词词云
- ✅ 主题聚类散点图（5个簇）
- ✅ 模型对比实验结果表

#### 功能3：智能问答
- ✅ 生成分析报告（LLM生成）
- ✅ 对话式追问

### 3.4 示例输出

#### 情感分析输出示例
```json
{
  "status": "success",
  "data": {
    "positive": {"count": 1000, "percentage": 33.3},
    "negative": {"count": 1000, "percentage": 33.3},
    "neutral": {"count": 1000, "percentage": 33.3},
    "total": 3000
  },
  "accuracy": 0.8623
}
```

#### 主题聚类输出示例
```json
{
  "status": "success",
  "clusters": [
    {"cluster_id": 0, "size": 1200, "keywords": ["人性", "感人", "催泪"]},
    {"cluster_id": 1, "size": 1100, "keywords": ["剧情", "故事", "情节"]}
  ],
  "visualization": "/api/visualization/clusters.png"
}
```

---

## 4. 项目结构

```
d:\LMA\test\
├── app.py                          # Flask主应用入口
├── data_loader.py                   # 数据加载工具
├── .env                            # 环境变量配置
├── requirements.txt                 # Python依赖列表
├── README.md                       # 项目说明文档
│
├── templates/
│   └── index.html                   # 前端HTML页面
│
├── nlp/                            # NLP处理模块
│   ├── __init__.py
│   ├── sentiment_analyzer.py       # 情感分析模块
│   ├── cluster_analyzer.py          # 主题聚类模块
│   ├── semantic_vectorizer.py       # Sentence-BERT向量化
│   ├── text_processor.py            # 文本预处理
│   └── stopwords.txt               # 停用词表
│
├── llm/                            # 大语言模型模块
│   ├── __init__.py
│   ├── report_generator.py          # 报告生成器
│   └── chatbot.py                   # 智能对话
│
└── data/                           # 数据目录
    ├── processed_comments.csv       # 处理后的评论数据
    └── output/                     # 输出目录
```

---

## 5. 核心算法说明

### 5.1 Sentence-BERT语义向量化
- **模型**：all-MiniLM-L6-v2
- **向量维度**：384
- **用途**：将评论文本转换为稠密向量表示

### 5.2 情感分类
- **模型**：逻辑回归（Logistic Regression）
- **类别**：正面、负面、中性

#### 模型对比实验结果

| 模型 | 准确率 | F1(Macro) | F1(Weighted) | 精确率 | 召回率 |
|------|--------|-----------|--------------|--------|--------|
| 高斯朴素贝叶斯 | 44.00% | 0.4359 | 0.4372 | 0.4370 | 0.4400 |
| SVM | 48.83% | 0.4799 | 0.4811 | 0.4811 | 0.4883 |
| 逻辑回归 | 49.33% | 0.4864 | 0.4874 | 0.4870 | 0.4933 |
| 随机森林 | 45.50% | 0.4537 | 0.4548 | 0.4546 | 0.4550 |

**实验结论**：
- 最佳模型：逻辑回归（准确率：49.33%）
- 错误案例数：608

### 5.3 主题聚类
- **算法**：K-Means
- **聚类数**：5
- **降维方法**：t-SNE
- **评估指标**：轮廓系数约0.52

### 5.4 智能报告生成

- **模型**：DeepSeek V4 (deepseek-v4-flash)
- **功能**：生成多维分析报告，支持对话式追问

---

## 6. 常见问题

### Q1: 启动时报错"Module not found"
**解决**：
```bash
pip install -r requirements.txt
```

### Q2: 报告生成失败
**解决**：
1. 检查`.env`文件是否正确配置API Key
2. 检查网络连接
3. 查看服务器日志错误信息

### Q3: 词云显示乱码
**解决**：
确保系统安装了中文字体，或修改`nlp/text_processor.py`中的字体路径

### Q4: 聚类分析速度慢
**解决**：
- 减少数据量：修改`cluster_analyzer.py`中的`max_samples`参数
- 使用GPU：安装CUDA版本的PyTorch

---

## 7. 版本历史

| 版本 | 日期 | 更新内容 |
|------|------|----------|
| v1.0.0 | 2025-01 | 初始版本，实现基础功能 |
| v1.1.0 | 2025-05 | 集成DeepSeek LLM，优化用户体验 |

---

**最后更新**：2025年5月