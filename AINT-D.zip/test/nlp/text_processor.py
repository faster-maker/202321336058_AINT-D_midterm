"""
文本处理模块

功能：
- 中文分词（使用jieba）
- 停用词过滤
- 词频统计
- 词云生成

依赖：
- jieba: 中文分词
- wordcloud: 词云生成
- collections.Counter: 词频统计

使用方法：
    from nlp.text_processor import generate_wordcloud, extract_keywords
    
    # 生成词云
    wordcloud_path = generate_wordcloud(target='Your Name')
    
    # 提取关键词
    keywords = extract_keywords(target='Your Name', top_n=20)
"""

import os
from wordcloud import WordCloud
from collections import Counter
import jieba

# 全局停用词集合
# 停用词是指在文本处理中需要过滤掉的高频无意义词语
stopwords = set()


def load_stopwords():
    """
    加载停用词表
    
    停用词来源：
        1. 从stopwords.txt文件加载（如果存在）
        2. 使用内置的默认停用词表作为备用
    
    默认停用词包括：
        - 常见助词：的、了、和、是、就
        - 代词：我们、你们、他们、这个、那个
        - 连词：因为、所以、但是、然而
        - 副词：已经、正在、曾经、将要
        - 介词：通过、经过、根据、按照
    """
    global stopwords
    
    # 尝试从文件加载停用词
    stopword_path = os.path.join(os.path.dirname(__file__), 'stopwords.txt')
    
    if os.path.exists(stopword_path):
        # 从文件加载停用词
        with open(stopword_path, 'r', encoding='utf-8') as f:
            stopwords = set(f.read().splitlines())
        print(f"已加载 {len(stopwords)} 个停用词")
    else:
        # 使用内置默认停用词表
        stopwords = set([
            # 助词：协助构成句子成分，无实际意义
            '的', '了', '和', '是', '就', '都', '而', '及', '与', '着', '或', '一个',
            
            # 代词：代替名词或数量
            '没有', '我们', '你们', '他们', '它们', '这个', '那个', '这些', '那些',
            
            # 疑问词：表示疑问
            '什么', '怎么', '如何', '为什么',
            
            # 连词：连接词语或句子
            '因为', '所以', '但是', '然而', '虽然', '如果', '能够', '可以',
            
            # 副词：修饰动词或形容词
            '可能', '应该', '必须', '需要', '已经', '正在', '曾经', '将要',
            
            # 介词：表示时间、空间、方式等关系
            '通过', '经过', '根据', '按照', '关于', '对于', '至于', '由于',
            
            # 其他常见无意义词
            '不会', '不能', '不要', '不妨', '显得', '觉得', '认为', '以为',
            
            # 动词（高频但无分析价值）
            '开始', '继续', '停止', '结束', '完成', '实现', '达到', '超过',
            
            # 数量词
            '这个', '那个', '一个', '一些', '一种', '一共', '一样'
        ])


def preprocess(text):
    """
    文本预处理
    
    参数：
        text (str): 原始评论文本
    
    返回：
        list: 处理后的词语列表
    
    处理流程：
        1. 去除首尾空白字符
        2. 使用jieba进行中文分词
        3. 过滤停用词
        4. 过滤单字词（长度<=1）
    
    示例：
        输入: "这部电影太棒了，特效非常震撼！"
        输出: ['电影', '太棒', '特效', '非常', '震撼']
    """
    # 去除首尾空白
    text = text.strip()
    
    # 使用jieba进行中文分词
    # jieba是最常用的中文分词库，支持精确模式、全模式和搜索引擎模式
    # 默认使用精确模式，试图将句子最精确地切开
    words = jieba.lcut(text)
    
    # 过滤处理
    # 1. 去除停用词
    # 2. 去除单字词（单字通常信息量少）
    words = [word for word in words if word not in stopwords and len(word) > 1]
    
    return words


def get_comments_texts(target=None):
    """
    从CSV文件获取评论文本
    
    参数：
        target (str, optional): 电影名称筛选
                               如果为None，则获取所有评论
    
    返回：
        list: 评论文本列表
    
    数据库查询说明：
        - 使用CSV文件存储数据
        - 支持按电影名称筛选
        - 自动处理文件不存在的情况
    """
    from data_loader import load_comments
    
    try:
        # 使用数据加载工具读取评论
        df = load_comments(target)
        
        # 提取评论文本列
        comments = df['text'].tolist()
        return comments
        
    except FileNotFoundError:
        print(f"错误: CSV文件不存在")
        return []


def get_word_frequency(target=None):
    """
    计算词频统计
    
    参数：
        target (str, optional): 电影名称筛选
    
    返回：
        Counter: 词频统计对象，格式为 {词语: 频次}
    
    算法流程：
        1. 获取评论文本列表
        2. 对每条评论进行分词和预处理
        3. 合并所有词语
        4. 使用Counter统计词频
    
    示例返回：
        Counter({
            '电影': 1520,
            '特效': 890,
            '剧情': 756,
            '演员': 623,
            ...
        })
    """
    # 获取评论列表
    comments = get_comments_texts(target)
    
    # 合并所有分词结果
    all_words = []
    
    for comment in comments:
        # 对每条评论进行分词
        words = preprocess(comment)
        # 添加到总词表
        all_words.extend(words)
    
    # 使用Counter统计词频
    word_counts = Counter(all_words)
    
    return word_counts


def get_font_path():
    """
    获取中文字体文件路径
    
    词云生成需要中文字体支持，否则无法正确显示中文
    
    搜索路径（按优先级）：
        1. 当前目录下的常见字体文件
        2. Windows系统字体目录
        3. Linux系统字体目录
    
    返回：
        str or None: 字体文件路径，如果都找不到则返回None
    """
    # 常见中文字体文件路径列表
    # 按优先级排序
    possible_paths = [
        # 当前目录
        'simhei.ttf',           # 微软雅黑
        'msyh.ttc',             # 微软雅黑（TTC格式）
        'STHeiti Light.ttc',    # 华文细黑
        'Arial Unicode.ttf',    # Arial Unicode
        
        # 当前模块目录
        os.path.join(os.path.dirname(__file__), 'simhei.ttf'),
        
        # Windows系统字体目录
        'C:\\Windows\\Fonts\\simhei.ttf',
        'C:\\Windows\\Fonts\\msyh.ttc',
        
        # Linux系统字体目录
        '/usr/share/fonts/truetype/wqy/wqy-microhei.ttc',
        '/usr/share/fonts/truetype/freefont/FreeSans.ttf',
    ]
    
    # 遍历查找存在的字体文件
    for path in possible_paths:
        if os.path.exists(path):
            return path
    
    # 都没找到，返回None
    return None


def generate_wordcloud(target=None):
    """
    生成词云图片
    
    参数：
        target (str, optional): 电影名称筛选
                              如果为None，则生成所有评论的词云
    
    返回：
        str or None: 词云图片的URL路径
                    例如：'/static/images/wordcloud_all.png'
                    如果生成失败，返回None
    
    词云配置参数：
        - background_color: 背景颜色，白色
        - width/height: 图片尺寸，800x600
        - max_words: 最大显示词数，80
        - max_font_size: 最大字体大小，100
        - min_font_size: 最小字体大小，10
        - random_state: 随机种子，保证结果可复现
    
    生成流程：
        1. 计算词频
        2. 配置词云参数
        3. 生成词云图片
        4. 保存到static/images目录
    """
    # 计算词频
    word_counts = get_word_frequency(target)
    
    # 如果没有词频数据，返回None
    if not word_counts:
        return None
    
    # 获取字体路径
    font_path = get_font_path()
    
    # 配置词云参数
    wc = WordCloud(
        font_path=font_path,          # 中文字体路径
        background_color='white',     # 白色背景
        width=800,                    # 宽度800像素
        height=600,                   # 高度600像素
        max_words=80,                 # 最多显示80个词
        max_font_size=100,           # 最大字体100像素
        min_font_size=10,            # 最小字体10像素
        random_state=42              # 随机种子，用于复现结果
    )
    
    try:
        # 使用词频生成词云
        # generate_from_frequencies根据词频自动设置词的大小
        wc.generate_from_frequencies(word_counts)
    except Exception as e:
        print(f"词云生成错误: {e}")
        return None
    
    # 确保输出目录存在
    image_dir = os.path.join(os.path.dirname(__file__), '..', 'static', 'images')
    os.makedirs(image_dir, exist_ok=True)
    
    # 生成安全的文件名
    # 替换特殊字符，防止路径注入
    safe_target = target.replace('/', '_').replace('\\', '_').replace(' ', '_') if target else 'all'
    filename = f'wordcloud_{safe_target}.png'
    image_path = os.path.join(image_dir, filename)
    
    try:
        # 保存词云图片
        wc.to_file(image_path)
        
        # 返回访问URL
        return f'/static/images/{filename}'
        
    except Exception as e:
        print(f"词云保存错误: {e}")
        return None


def extract_keywords(target=None, top_n=20):
    """
    提取关键词
    
    参数：
        target (str, optional): 电影名称筛选
        top_n (int): 返回的关键词数量，默认20
    
    返回：
        list: 关键词列表，格式为：
            [
                {'word': '电影', 'count': 1520},
                {'word': '特效', 'count': 890},
                ...
            ]
    
    算法说明：
        直接使用词频统计，按频次降序排列取前N个
    
    与词云的区别：
        - 词云：可视化展示
        - 关键词：数据化的关键词列表，便于程序处理
    """
    # 获取词频统计
    word_counts = get_word_frequency(target)
    
    # 取最高频的N个词
    keywords = word_counts.most_common(top_n)
    
    # 转换为指定格式
    return [{'word': word, 'count': count} for word, count in keywords]


# 模块初始化时加载停用词
load_stopwords()
