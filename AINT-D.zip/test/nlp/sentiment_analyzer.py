"""
情感分析模块

功能：
- 基于Sentence-BERT和逻辑回归模型的情感三分类（正面/负面/中性）
- 用于实际预测和分析

使用方法：
    from nlp.sentiment_analyzer import analyze_comments
    result = analyze_comments('釜山行')
"""

import pandas as pd
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import os

# 模型缓存
_model_cache = None


def get_trained_model():
    """获取训练好的模型（带缓存）"""
    global _model_cache
    if _model_cache is None:
        print("首次调用，开始训练模型...")
        _model_cache = _train_model()
        print("模型训练完成！")
    return _model_cache


def _train_model():
    """训练情感分析模型"""
    from data_loader import load_comments
    from nlp.semantic_vectorizer import get_vectorizer
    
    print("开始训练情感分析模型...")
    
    # 加载所有评论数据
    df = load_comments()
    
    # 将情感标签转换为数值：0=负面, 1=中性, 2=正面
    sentiment_mapping = {'negative': 0, 'neutral': 1, 'positive': 2}
    df['label'] = df['sentiment'].map(sentiment_mapping)
    
    # 移除未映射的标签
    df = df.dropna(subset=['label'])
    df['label'] = df['label'].astype(int)
    
    X_text = df['text'].values
    y = df['label'].values
    
    print(f"训练样本数: {len(X_text)}")
    print(f"  正面评论: {sum(y == 2)} 条")
    print(f"  中性评论: {sum(y == 1)} 条")
    print(f"  负面评论: {sum(y == 0)} 条")
    
    # 使用Sentence-BERT向量化
    print("\n使用Sentence-BERT进行文本向量化...")
    vectorizer = get_vectorizer()
    X = vectorizer.encode(X_text.tolist())
    
    # 划分训练集和测试集
    X_train, X_test, y_train, y_test, texts_train, texts_test = train_test_split(
        X, y, X_text, test_size=0.2, random_state=42
    )
    
    print(f"\n训练集: {X_train.shape[0]} 条")
    print(f"测试集: {X_test.shape[0]} 条")
    
    # 训练逻辑回归模型
    print("\n训练逻辑回归模型...")
    model = LogisticRegression(
        max_iter=1000,
        class_weight='balanced',
        random_state=42
    )
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    
    # 评估
    accuracy = accuracy_score(y_test, y_pred)
    report = classification_report(y_test, y_pred, target_names=['负面', '中性', '正面'], output_dict=True, zero_division=0)
    cm = confusion_matrix(y_test, y_pred)
    
    # 转换classification_report中的numpy类型
    def convert_numpy_types(obj):
        if isinstance(obj, dict):
            return {k: convert_numpy_types(v) for k, v in obj.items()}
        elif isinstance(obj, np.integer):
            return int(obj)
        elif isinstance(obj, np.floating):
            return float(obj)
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        else:
            return obj
    
    report = convert_numpy_types(report)
    
    print(f"\n模型训练完成！")
    print(f"  准确率: {accuracy:.2%}")
    
    # 分析错误案例
    errors = []
    for i, (true, pred) in enumerate(zip(y_test, y_pred)):
        if true != pred:
            errors.append({
                'text': texts_test[i],
                'true_label': ['负面', '中性', '正面'][true],
                'pred_label': ['负面', '中性', '正面'][pred]
            })
    
    # 保存错误案例
    os.makedirs('output', exist_ok=True)
    if errors:
        errors_df = pd.DataFrame(errors)
        errors_df.to_csv('output/sentiment_errors.csv', index=False, encoding='utf-8')
        print(f"错误案例已保存到: output/sentiment_errors.csv")
    
    return {
        'vectorizer': vectorizer,
        'model': model,
        'accuracy': float(accuracy),
        'classification_report': report,
        'confusion_matrix': cm.tolist(),
        'errors': errors
    }


def predict_sentiment(text, vectorizer, model):
    """预测单条评论的情感"""
    X = vectorizer.encode([text])
    prediction = model.predict(X)[0]
    label_names = {0: 'negative', 1: 'neutral', 2: 'positive'}
    return label_names[prediction]


def analyze_comments(target=None):
    """分析评论的情感分布（使用训练好的模型进行预测，任务2要求）"""
    from data_loader import load_comments
    
    print(f"\n开始分析情感分布...")
    if target:
        print(f"  目标电影: {target}")
    else:
        print(f"  分析范围: 所有电影")
    
    df = load_comments(target)
    
    if len(df) == 0:
        return {
            'total': 0,
            'positive': {'count': 0, 'percentage': 0},
            'negative': {'count': 0, 'percentage': 0},
            'neutral': {'count': 0, 'percentage': 0},
            'positive_samples': [],
            'negative_samples': [],
            'neutral_samples': [],
            'model_accuracy': 0
        }
    
    # 获取训练好的模型（训练集:测试集=8:2，固定种子random_state=42）
    model_data = get_trained_model()
    accuracy = model_data['accuracy']
    vectorizer = model_data['vectorizer']
    model = model_data['model']
    
    # 使用模型预测情感
    texts = df['text'].values
    X = vectorizer.encode(texts.tolist())
    predictions = model.predict(X)
    
    # 将预测标签转换为文字
    label_names = {0: 'negative', 1: 'neutral', 2: 'positive'}
    predicted_sentiments = [label_names[p] for p in predictions]
    
    # 统计预测结果
    total = int(len(df))
    positive_count = sum(1 for s in predicted_sentiments if s == 'positive')
    negative_count = sum(1 for s in predicted_sentiments if s == 'negative')
    neutral_count = sum(1 for s in predicted_sentiments if s == 'neutral')
    
    # 获取各类评论示例（根据预测结果）
    df['predicted_sentiment'] = predicted_sentiments
    positive_samples = df[df['predicted_sentiment'] == 'positive']['text'].head(5).tolist()
    negative_samples = df[df['predicted_sentiment'] == 'negative']['text'].head(5).tolist()
    neutral_samples = df[df['predicted_sentiment'] == 'neutral']['text'].head(5).tolist()
    
    positive_pct = (positive_count / total * 100) if total > 0 else 0
    negative_pct = (negative_count / total * 100) if total > 0 else 0
    neutral_pct = (neutral_count / total * 100) if total > 0 else 0
    
    print(f"\n分析完成!")
    print(f"  总评论数: {total}")
    print(f"  正面评论: {positive_count} ({positive_pct:.1f}%)")
    print(f"  负面评论: {negative_count} ({negative_pct:.1f}%)")
    print(f"  中性评论: {neutral_count} ({neutral_pct:.1f}%)")
    print(f"  模型准确率: {accuracy:.2%}（测试集上表现）")
    
    return {
        'total': total,
        'positive': {
            'count': positive_count,
            'percentage': round(positive_pct, 1)
        },
        'negative': {
            'count': negative_count,
            'percentage': round(negative_pct, 1)
        },
        'neutral': {
            'count': neutral_count,
            'percentage': round(neutral_pct, 1)
        },
        'positive_samples': positive_samples,
        'negative_samples': negative_samples,
        'neutral_samples': neutral_samples,
        'model_accuracy': float(accuracy)
    }


if __name__ == '__main__':
    print("="*60)
    print("情感分析模块测试")
    print("="*60)
    
    result = analyze_comments('釜山行')
    print("\n分析结果:")
    print(f"  总评论数: {result['total']}")
    print(f"  正面: {result['positive']['count']} ({result['positive']['percentage']}%)")
    print(f"  中性: {result['neutral']['count']} ({result['neutral']['percentage']}%)")
    print(f"  负面: {result['negative']['count']} ({result['negative']['percentage']}%)")
    print(f"  模型准确率: {result['model_accuracy']:.2%}")
