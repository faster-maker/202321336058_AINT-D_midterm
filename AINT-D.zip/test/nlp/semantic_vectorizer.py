"""
深度语义向量化模块

功能：
- 使用Sentence-BERT进行文本向量化
- 提供语义相似度计算
- 使用sentence-transformers库

算法说明：
- 使用all-MiniLM-L6-v2轻量级模型（约80MB）
- 专为句子嵌入优化的BERT模型
- 支持多种语言，包括中文

使用方法：
    from nlp.semantic_vectorizer import SemanticVectorizer
    
    # 创建向量化器
    vectorizer = SemanticVectorizer()
    
    # 向量化文本
    embeddings = vectorizer.encode(["这是一条评论", "这是另一条评论"])
    
    # 计算相似度
    similarity = vectorizer.similarity(embeddings[0], embeddings[1])
"""

import os
import numpy as np

# 设置 huggingface 国内镜像
os.environ['HF_ENDPOINT'] = 'https://hf-mirror.com'

class SemanticVectorizer:
    """
    深度语义向量化器（基于Sentence-BERT）
    """
    
    def __init__(self, model_name='all-MiniLM-L6-v2'):
        """
        初始化向量化器
        
        参数：
            model_name (str): 预训练模型名称
                - 'all-MiniLM-L6-v2': 轻量级模型，384维，约80MB
        """
        self.model_name = model_name
        self.model = None
        self._util = None
    
    def _load_model(self):
        """
        加载Sentence-BERT模型
        """
        if self.model is not None:
            return
        
        try:
            from sentence_transformers import SentenceTransformer, util
            
            print(f"正在加载Sentence-BERT模型: {self.model_name}")
            self.model = SentenceTransformer(self.model_name)
            self._util = util
            print(f"Sentence-BERT模型加载成功! 向量维度: {self.model.get_embedding_dimension()}")
        
        except ImportError as e:
            print(f"sentence_transformers库未安装: {e}")
            raise ImportError("请先安装sentence_transformers库: pip install sentence-transformers")
        except Exception as e:
            print(f"模型加载失败: {e}")
            raise RuntimeError(f"模型加载失败: {e}")
    
    def encode(self, texts, batch_size=8, show_progress_bar=False):
        """
        将文本转换为语义向量
        
        参数：
            texts (list): 文本列表
            batch_size (int): 批处理大小
            show_progress_bar (bool): 是否显示进度条
        
        返回：
            numpy.ndarray: 语义向量矩阵，shape=(n_samples, n_dimensions)
        """
        self._load_model()
        
        if not isinstance(texts, list):
            texts = [texts]
        
        print(f"  编码文本数: {len(texts)}, 批处理大小: {batch_size}")
        
        embeddings = self.model.encode(
            texts,
            batch_size=batch_size,
            show_progress_bar=show_progress_bar,
            convert_to_numpy=True,
            normalize_embeddings=False
        )
        
        print(f"  向量维度: {embeddings.shape}")
        return embeddings
    
    def similarity(self, vec1, vec2):
        """
        计算两个向量的余弦相似度
        
        参数：
            vec1 (numpy.ndarray): 向量1
            vec2 (numpy.ndarray): 向量2
        
        返回：
            float: 余弦相似度，范围[-1, 1]，越接近1越相似
        """
        if self._util is None:
            self._load_model()
        return self._util.cos_sim(vec1, vec2).item()
    
    def similarity_matrix(self, embeddings):
        """
        计算向量矩阵的相似度矩阵
        
        参数：
            embeddings (numpy.ndarray): 向量矩阵
        
        返回：
            numpy.ndarray: 相似度矩阵，shape=(n_samples, n_samples)
        """
        if self._util is None:
            self._load_model()
        return self._util.cos_sim(embeddings, embeddings).numpy()

# 全局实例，方便使用
_global_vectorizer = None

def get_vectorizer():
    """
    获取全局语义向量化器实例
    
    返回：
        SemanticVectorizer: 向量化器实例
    """
    global _global_vectorizer
    if _global_vectorizer is None:
        _global_vectorizer = SemanticVectorizer()
    return _global_vectorizer

def encode_texts(texts):
    """
    便捷函数：将文本列表转换为语义向量
    
    参数：
        texts (list): 文本列表
    
    返回：
        numpy.ndarray: 语义向量矩阵
    """
    vectorizer = get_vectorizer()
    return vectorizer.encode(texts)

if __name__ == '__main__':
    """
    测试深度语义向量化模块
    """
    print("="*60)
    print("深度语义向量化模块测试")
    print("="*60)
    
    # 创建向量化器
    vectorizer = SemanticVectorizer()
    
    # 测试文本
    texts = [
        "这部电影的特效非常震撼",
        "电影的视觉效果很棒",
        "剧情很无聊，浪费时间",
        "演员的表演很出色"
    ]
    
    print("\n1. 测试文本向量化...")
    embeddings = vectorizer.encode(texts)
    print(f"   输入文本数: {len(texts)}")
    print(f"   向量维度: {embeddings.shape}")
    
    print("\n2. 测试语义相似度...")
    sim1 = vectorizer.similarity(embeddings[0], embeddings[1])
    sim2 = vectorizer.similarity(embeddings[0], embeddings[2])
    print(f"   '特效震撼' 与 '视觉效果棒' 的相似度: {sim1:.4f}")
    print(f"   '特效震撼' 与 '剧情无聊' 的相似度: {sim2:.4f}")
    
    print("\n" + "="*60)
    print("测试完成!")
    print("="*60)