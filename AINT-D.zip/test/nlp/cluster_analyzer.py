"""
主题聚类分析模块 - 简化版

功能：
- 使用Sentence-BERT进行文本向量化
- K-Means聚类算法
- t-SNE降维可视化
- 提取每个簇的关键词
- 生成主题词云
- 生成主题标签

算法流程：
1. 文本向量化（Sentence-BERT）
2. 聚类（K-Means）
3. t-SNE降维至2D
4. 提取簇关键词
5. 生成主题词云
6. 生成主题标签
7. 计算轮廓系数

使用方法：
    from nlp.cluster_analyzer import analyze_clusters

    # 分析所有评论的主题
    result = analyze_clusters()
"""

import numpy as np
import pandas as pd
import os
import csv
from sklearn.cluster import KMeans
from sklearn.manifold import TSNE
from sklearn.metrics import silhouette_score
from collections import Counter
from wordcloud import WordCloud

def get_font_path():
    possible_paths = [
        'simhei.ttf',
        'msyh.ttc',
        os.path.join(os.path.dirname(__file__), 'simhei.ttf'),
        'C:\\Windows\\Fonts\\simhei.ttf',
        'C:\\Windows\\Fonts\\msyh.ttc',
        '/usr/share/fonts/truetype/wqy/wqy-microhei.ttc',
    ]
    for path in possible_paths:
        if os.path.exists(path):
            return path
    return None

def extract_cluster_keywords(texts, vectorizer, labels, n_terms=10):
    """提取每个簇的关键词"""
    if vectorizer is None:
        return {}
    
    feature_names = vectorizer.get_feature_names_out()
    unique_labels = np.unique(labels)
    cluster_keywords = {}
    
    for label in unique_labels:
        if label == -1:
            continue
        cluster_indices = np.where(labels == label)[0]
        
        if len(cluster_indices) == 0:
            cluster_keywords[label] = ['无']
            continue
        
        cluster_vectors = vectorizer.transform([texts[i] for i in cluster_indices])
        mean_vector = cluster_vectors.mean(axis=0).A1
        
        top_indices = mean_vector.argsort()[-n_terms:][::-1]
        keywords = [feature_names[i] for i in top_indices]
        
        cluster_keywords[label] = keywords
    
    return cluster_keywords

def generate_cluster_wordcloud(texts, labels, output_dir='static/images'):
    """为每个簇生成词云"""
    from nlp.text_processor import preprocess
    
    os.makedirs(output_dir, exist_ok=True)
    font_path = get_font_path()
    wordcloud_paths = {}
    
    unique_labels = np.unique(labels)
    for label in unique_labels:
        if label == -1:
            continue
        cluster_indices = np.where(labels == label)[0]
        cluster_texts = [texts[i] for i in cluster_indices]
        
        all_words = []
        for text in cluster_texts:
            words = preprocess(text)
            all_words.extend(words)
        
        if not all_words:
            wordcloud_paths[label] = None
            continue
        
        word_counts = Counter(all_words)
        
        wc = WordCloud(
            font_path=font_path,
            background_color='white',
            width=600,
            height=400,
            max_words=50,
            max_font_size=80,
            random_state=42
        )
        
        wc.generate_from_frequencies(word_counts)
        
        filename = f'wordcloud_cluster_{label}.png'
        image_path = os.path.join(output_dir, filename)
        wc.to_file(image_path)
        
        wordcloud_paths[label] = f'/static/images/{filename}'
    
    return wordcloud_paths

def generate_topic_labels(clusters):
    """为每个簇生成主题标签（使用关键词生成）"""
    topic_labels = {}
    
    for cluster in clusters:
        cluster_id = cluster['cluster_id']
        keywords = cluster.get('keywords', [])
        if keywords:
            label = ''.join([kw[0] for kw in keywords[:3]])[:5]
            topic_labels[cluster_id] = label if label else f"主题{cluster_id}"
        else:
            topic_labels[cluster_id] = f"主题{cluster_id}"
    
    return topic_labels

def analyze_clusters(target=None, n_clusters=5, max_samples=100000):
    """
    对评论进行主题聚类分析

    参数：
        target (str): 电影名称筛选
        n_clusters (int): 聚类数量
        max_samples (int): 最大处理样本数（用于内存优化）

    返回：
        dict: 聚类结果
    """
    from data_loader import load_comments
    
    print(f"\n开始主题聚类分析...")
    if target:
        print(f"  目标电影: {target}")
    else:
        print(f"  分析范围: 所有电影")
    print(f"  聚类数量: {n_clusters}")
    print(f"  最大样本数: {max_samples}")

    df = load_comments(target)

    if len(df) < 2:
        return {
            'error': f'评论数量({len(df)})不足，无法进行聚类',
            'n_clusters': 0,
            'clusters': [],
            'visualization': {'coordinates': [], 'labels': []},
            'silhouette_score': 0,
            'topic_labels': {},
            'total_comments': int(len(df)),
            'analyzed_comments': int(len(df)),
            'sampled': False
        }

    # 采样处理以优化内存使用（可选，也可以使用全部数据）
    if len(df) > max_samples:
        df_sample = df.sample(max_samples, random_state=42)
        print(f"\n文本数量: {len(df_sample)} (从{len(df)}条中采样)")
    else:
        df_sample = df
        print(f"\n文本数量: {len(df_sample)} (使用全部数据)")
    texts = df_sample['text'].tolist()

    # 文本向量化
    print("正在进行文本向量化...")
    from nlp.semantic_vectorizer import encode_texts
    X = encode_texts(texts)
    print(f"使用Sentence-BERT向量化: {X.shape}")

    # 执行K-Means聚类
    print("正在执行K-Means聚类...")
    model = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
    labels = model.fit_predict(X)
    n_clusters_actual = n_clusters

    # 计算轮廓系数（仅当有多个簇时）
    silhouette = 0
    if n_clusters_actual > 1:
        silhouette = silhouette_score(X, labels)
        print(f"轮廓系数: {silhouette:.3f}")

    # 提取关键词
    cluster_keywords = {}
    print("正在提取簇关键词...")
    from sklearn.feature_extraction.text import TfidfVectorizer
    keyword_vectorizer = TfidfVectorizer(
        max_features=2000,
        ngram_range=(1, 2),
        min_df=2
    )
    keyword_vectorizer.fit(texts)
    cluster_keywords = extract_cluster_keywords(texts, keyword_vectorizer, labels)

    # 构建簇信息
    clusters = []
    unique_labels = np.unique(labels)
    for label in unique_labels:
        if label == -1:
            continue
        
        cluster_indices = np.where(labels == label)[0]
        
        cluster_info = {
            'cluster_id': int(label),
            'size': int(len(cluster_indices)),
            'keywords': cluster_keywords.get(int(label), []),
            'samples': [texts[i] for i in cluster_indices[:3]]
        }
        clusters.append(cluster_info)
        
        print(f"\n簇 {label} ({len(cluster_indices)} 条评论)")
        if cluster_keywords.get(label):
            print(f"  关键词: {', '.join(cluster_keywords[label][:5])}")

    # 生成主题词云
    print("\n正在生成主题词云...")
    wordcloud_paths = generate_cluster_wordcloud(texts, labels)

    # 生成主题标签
    print("正在生成主题标签...")
    topic_labels = generate_topic_labels(clusters)

    # t-SNE降维可视化
    print("\n正在进行t-SNE降维...")
    perplexity = min(30, len(texts) - 1)
    reducer = TSNE(n_components=2, random_state=42, perplexity=perplexity)
    coordinates = reducer.fit_transform(X)

    visualization = {
        'coordinates': coordinates.tolist(),
        'labels': [int(l) for l in labels.tolist()],
        'method': 't-SNE'
    }

    # 保存聚类结果到CSV
    output_dir = 'output'
    os.makedirs(output_dir, exist_ok=True)
    cluster_file = os.path.join(output_dir, 'cluster_results_kmeans.csv')

    with open(cluster_file, 'w', encoding='utf-8-sig', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['cluster_id', 'topic_label', 'size', 'keywords', 'sample_comments'])
        for cluster in clusters:
            writer.writerow([
                cluster['cluster_id'],
                topic_labels.get(cluster['cluster_id'], ''),
                cluster['size'],
                ','.join(cluster['keywords']),
                ' || '.join(cluster['samples'])
            ])
    print(f"聚类结果已保存到: {cluster_file}")

    print(f"\n聚类分析完成!")
    print(f"  聚类数量: {n_clusters_actual}")
    print(f"  轮廓系数: {silhouette:.3f}")
    print(f"  降维方法: t-SNE")

    # 将topic_labels的整数键转换为字符串键，以便JSON序列化
    topic_labels_str = {str(k): v for k, v in topic_labels.items()}
    wordcloud_paths_str = {str(k): v for k, v in wordcloud_paths.items()}
    
    return {
        'n_clusters': int(n_clusters_actual),
        'clusters': clusters,
        'visualization': visualization,
        'silhouette_score': float(silhouette),
        'topic_labels': topic_labels_str,
        'wordcloud_paths': wordcloud_paths_str,
        'total_comments': int(len(df)),
        'analyzed_comments': int(len(texts)),
        'sampled': len(df) > max_samples
    }
