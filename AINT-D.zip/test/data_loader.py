"""
数据加载工具模块

功能：
- 提供统一的数据加载接口
- 从CSV文件读取评论数据
- 支持按电影名称筛选

使用方法：
    from data_loader import load_comments, get_targets
    
    # 加载所有评论
    df = load_comments()
    
    # 加载指定电影的评论
    df = load_comments(target='Your Name')
"""

import pandas as pd
import os

# CSV文件路径
CSV_FILE = 'data/processed_comments.csv'


def load_comments(target=None):
    """
    从CSV文件加载评论数据
    
    参数：
        target (str, optional): 电影名称筛选（支持中文或英文名称）
                              如果为None，则加载所有评论
    
    返回：
        DataFrame: 评论数据，包含字段：
            - id: 评论ID
            - text: 评论文本
            - rating: 评分
            - target: 电影中文名称
            - sentiment: 情感标签
    
    示例：
        # 加载所有评论
        df = load_comments()
        
        # 加载指定电影的评论（中文名称）
        df = load_comments(target='复仇者联盟2')
    """
    # 检查文件是否存在
    if not os.path.exists(CSV_FILE):
        raise FileNotFoundError(f"数据文件不存在: {CSV_FILE}")
    
    # 读取CSV文件
    df = pd.read_csv(CSV_FILE)
    
    # 尝试读取movies.csv获取中英文映射
    movies_csv = 'data/movies.csv'
    name_map = {}
    reverse_map = {}
    if os.path.exists(movies_csv):
        movies_df = pd.read_csv(movies_csv)
        # 创建英文到中文的映射字典
        name_map = dict(zip(movies_df['title'], movies_df['title_cn']))
        # 创建中文到英文的反向映射
        reverse_map = dict(zip(movies_df['title_cn'], movies_df['title']))
    
    # 如果传入的是中文名称，转换为英文名称进行筛选
    if target and target in reverse_map:
        target = reverse_map[target]
    
    # 按电影名称筛选
    if target:
        df = df[df['target'] == target]
    
    # 将评论中的英文电影名转换为中文
    df['target'] = df['target'].apply(lambda x: name_map.get(x, x))
    
    return df


def get_targets():
    """
    获取所有电影名称列表（中文）
    
    返回：
        list: 电影中文名称列表，按拼音顺序排序
    
    示例：
        targets = get_targets()
        # ['大鱼海棠', '大圣归来', '复仇者联盟2', ...]
    """
    # 检查文件是否存在
    if not os.path.exists(CSV_FILE):
        return []
    
    # 读取评论CSV文件获取英文电影名
    df = pd.read_csv(CSV_FILE)
    english_targets = sorted(df['target'].unique().tolist())
    
    # 尝试读取movies.csv获取中文映射
    movies_csv = 'data/movies.csv'
    if os.path.exists(movies_csv):
        movies_df = pd.read_csv(movies_csv)
        # 创建英文到中文的映射字典
        name_map = dict(zip(movies_df['title'], movies_df['title_cn']))
        
        # 将英文名称转换为中文名称
        targets = []
        for eng_name in english_targets:
            # 如果有中文映射则使用中文，否则保留英文
            cn_name = name_map.get(eng_name, eng_name)
            targets.append(cn_name)
        
        return targets
    else:
        # 如果没有movies.csv，返回英文名称
        return english_targets


def get_statistics():
    """
    获取数据集统计信息
    
    返回：
        dict: 统计数据，包含：
            - total: 总评论数
            - positive: 正面评论数
            - negative: 负面评论数
            - neutral: 中性评论数
            - movie_count: 电影数量
    """
    # 检查文件是否存在
    if not os.path.exists(CSV_FILE):
        return {
            'total': 0,
            'positive': 0,
            'negative': 0,
            'neutral': 0,
            'movie_count': 0
        }
    
    # 读取CSV文件
    df = pd.read_csv(CSV_FILE)
    
    # 统计
    total = len(df)
    positive = len(df[df['sentiment'] == 'positive'])
    negative = len(df[df['sentiment'] == 'negative'])
    neutral = len(df[df['sentiment'] == 'neutral'])
    movie_count = df['target'].nunique()
    
    return {
        'total': total,
        'positive': positive,
        'negative': negative,
        'neutral': neutral,
        'movie_count': movie_count
    }


def add_comment(text, target, rating=3):
    """
    添加新评论到CSV文件
    
    参数：
        text (str): 评论文本
        target (str): 电影名称
        rating (int): 评分，1-5分
    
    返回：
        int: 新评论的ID
    """
    # 读取现有数据
    if os.path.exists(CSV_FILE):
        df = pd.read_csv(CSV_FILE)
        next_id = df['id'].max() + 1
    else:
        df = pd.DataFrame()
        next_id = 1
    
    # 确定情感标签
    if rating >= 4:
        sentiment = 'positive'
    elif rating <= 2:
        sentiment = 'negative'
    else:
        sentiment = 'neutral'
    
    # 创建新评论
    new_comment = pd.DataFrame([{
        'id': next_id,
        'text': text,
        'rating': rating,
        'target': target,
        'sentiment': sentiment
    }])
    
    # 追加到数据框
    df = pd.concat([df, new_comment], ignore_index=True)
    
    # 保存到CSV文件
    df.to_csv(CSV_FILE, index=False)
    
    return next_id


if __name__ == '__main__':
    """
    测试数据加载功能
    """
    print("="*60)
    print("数据加载模块测试")
    print("="*60)
    
    # 测试加载所有评论
    print("\n1. 测试加载所有评论...")
    df = load_comments()
    print(f"   总评论数: {len(df)}")
    print(f"   列名: {df.columns.tolist()}")
    
    # 测试加载指定电影的评论
    print("\n2. 测试加载指定电影的评论...")
    if len(df) > 0:
        sample_movie = df['target'].iloc[0]
        df_movie = load_comments(target=sample_movie)
        print(f"   电影: {sample_movie}")
        print(f"   评论数: {len(df_movie)}")
    
    # 测试获取电影列表
    print("\n3. 测试获取电影列表...")
    targets = get_targets()
    print(f"   电影数量: {len(targets)}")
    print(f"   前5部电影: {targets[:5]}")
    
    # 测试统计信息
    print("\n4. 测试统计信息...")
    stats = get_statistics()
    print(f"   总评论: {stats['total']}")
    print(f"   正面: {stats['positive']} ({stats['positive']/stats['total']*100:.1f}%)")
    print(f"   负面: {stats['negative']} ({stats['negative']/stats['total']*100:.1f}%)")
    print(f"   中性: {stats['neutral']} ({stats['neutral']/stats['total']*100:.1f}%)")
    
    print("\n" + "="*60)
    print("测试完成!")
    print("="*60)
