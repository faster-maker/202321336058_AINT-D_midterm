"""
智能对话模块

功能：
- 基于DeepSeek大语言模型的对话式问答
- 支持情感分析和主题聚类上下文
- 维护对话历史

使用方法：
    from llm.chatbot import chat_response

    # 生成对话回复
    reply = chat_response('这部电影的主要优点是什么？', '釜山行')
"""

import os
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

# 初始化OpenAI客户端（配置DeepSeek API）
client = OpenAI(
    api_key=os.getenv('DEEPSEEK_API_KEY', ''),
    base_url=os.getenv('DEEPSEEK_API_URL', 'https://api.deepseek.com')
)

# 对话历史记录（全局变量）
conversation_history = []

def get_context(target=None):
    """
    获取分析上下文信息

    参数：
        target (str): 电影名称

    返回：
        str: 包含情感分析和主题聚类信息的上下文字符串
    """
    from nlp.sentiment_analyzer import analyze_comments
    from nlp.cluster_analyzer import analyze_clusters
    
    context = ""
    
    sentiment_data = analyze_comments(target)
    context += f"""
情感分析数据：
- 正面评论: {sentiment_data.get('positive', {}).get('count', 0)}条 ({sentiment_data.get('positive', {}).get('percentage', 0)}%)
- 负面评论: {sentiment_data.get('negative', {}).get('count', 0)}条 ({sentiment_data.get('negative', {}).get('percentage', 0)}%)
- 中性评论: {sentiment_data.get('neutral', {}).get('count', 0)}条 ({sentiment_data.get('neutral', {}).get('percentage', 0)}%)
"""
    
    cluster_data = analyze_clusters(target=target, n_clusters=5)
    clusters = cluster_data.get('clusters', [])
    context += f"\n主题簇信息（共{len(clusters)}个）:\n"
    for cluster in clusters:
        cluster_id = cluster.get('cluster_id', 0)
        keywords = cluster.get('keywords', [])
        size = cluster.get('size', 0)
        context += f"簇{cluster_id}: {', '.join(keywords[:5])} ({size}条评论)\n"
    
    return context

def chat_response(message, target=None, history=None):
    """
    生成对话回复

    参数：
        message (str): 用户输入的问题
        target (str): 电影名称
        history (list): 对话历史记录（可选）

    返回：
        str: AI生成的回复内容
    """
    global conversation_history
    
    context = get_context(target)
    
    system_prompt = f"""
You are a helpful movie review analysis assistant. Answer the user's questions based on the following analysis context.

Analysis target: {target or 'All movie reviews'}

Analysis context:
{context}

Requirements:
1. Answer clearly and accurately based on the provided context
2. State if no relevant information is available
3. Maintain conversation coherence
"""
    
    messages = [{"role": "system", "content": system_prompt}]
    
    if history:
        for msg in history[-5:]:
            messages.append({"role": msg["role"], "content": msg["content"]})
    else:
        for msg in conversation_history[-5:]:
            messages.append({"role": msg["role"], "content": msg["content"]})
    
    messages.append({"role": "user", "content": message})
    
    try:
        response = client.chat.completions.create(
            model="deepseek-v4-flash",
            messages=messages,
            max_tokens=1500,
            temperature=0.7
        )
        
        api_message = response.choices[0].message
        answer = api_message.content or getattr(api_message, 'reasoning_content', '') or '未能获取到响应内容'
        
        conversation_history.append({"role": "user", "content": message})
        conversation_history.append({"role": "assistant", "content": answer})
        
        return answer
    except Exception as e:
        return f"对话生成失败: {str(e)}"

def clear_history():
    global conversation_history
    conversation_history = []

if __name__ == '__main__':
    while True:
        user_input = input("你: ")
        if user_input.lower() == 'exit':
            break
        print("助手:", chat_response(user_input))