"""
报告生成模块

功能：
- 生成电影评论分析报告（任务4：对话式报告生成）
- 支持三分类情感分析
- 基于深度语义聚类的主题分析

使用方法：
    from llm.report_generator import generate_report

    # 生成完整分析报告
    report = generate_report('釜山行')
"""

import os
from dotenv import load_dotenv

load_dotenv()

def get_comments(target=None):
    """获取评论数据"""
    from data_loader import load_comments
    df = load_comments(target)
    return df['text'].tolist()

def get_sentiment_analysis(target=None):
    """获取情感分析结果"""
    from nlp.sentiment_analyzer import analyze_comments
    return analyze_comments(target)

def get_cluster_analysis(target=None):
    """获取聚类分析结果"""
    from nlp.cluster_analyzer import analyze_clusters
    return analyze_clusters(target, max_samples=100000)

def generate_report(target=None):
    """
    生成完整的评论分析报告（任务4：对话式报告生成）

    参数：
        target (str): 电影名称（可选）

    返回：
        str: Markdown格式的分析报告
    """
    print(f"===== 开始生成报告 for {target} =====")
    try:
        comments = get_comments(target)
        if not comments:
            return "暂无相关评论数据，无法生成报告。"

        print("正在获取情感分析数据...")
        sentiment_data = get_sentiment_analysis(target)

        print("正在获取聚类分析数据...")
        cluster_data = get_cluster_analysis(target)

        print("正在获取关键词数据...")
        from nlp.text_processor import extract_keywords
        keywords = extract_keywords(target, top_n=15)
        keyword_list = [kw['word'] for kw in keywords]

        positive_count = sentiment_data.get('positive', {}).get('count', 0)
        negative_count = sentiment_data.get('negative', {}).get('count', 0)
        neutral_count = sentiment_data.get('neutral', {}).get('count', 0)
        total = sentiment_data.get('total', len(comments))

        # 构建聚类信息
        cluster_info = ""
        for cluster in cluster_data.get('clusters', []):
            cluster_id = cluster.get('cluster_id', 0)
            topic_label = cluster_data.get('topic_labels', {}).get(str(cluster_id), f'主题{cluster_id}')
            cluster_keywords = cluster.get('keywords', [])
            size = cluster.get('size', 0)
            cluster_info += f"- **{topic_label}**: {size}条评论，关键词: {', '.join(cluster_keywords[:5])}\n"

        from datetime import datetime
        current_date = datetime.now().strftime("%Y年%m月%d日")

        # 构建LLM提示词
        prompt = f"""
你是一位专业的电影评论分析专家。请基于以下数据，为电影《{target}》撰写一份深入、专业且易于理解的评论分析报告。

---

**分析数据：**

📊 **基本信息**
- 报告日期: {current_date}
- 分析对象: {target}
- 评论总数: {total} 条

💬 **情感分布**
- 正面评论: {positive_count}条 ({positive_count/total*100:.1f}%)
- 负面评论: {negative_count}条 ({negative_count/total*100:.1f}%)
- 中性评论: {neutral_count}条 ({neutral_count/total*100:.1f}%)

🔑 **高频关键词**
{', '.join(keyword_list)}

🎯 **主题聚类结果**
{cluster_info}

---

**任务要求：**

请生成一份高质量的分析报告，包含以下部分：

1. **执行摘要**：用简洁的语言总结主要发现和关键洞察

2. **情感分析**：深入分析情感分布，解释为什么会有这样的分布，用户的整体态度如何

3. **主题分析**：分析各个主题簇的内容，解读用户关注的焦点话题，识别热门讨论点

4. **深度洞察**：基于数据提出有价值的见解和发现，包括：
   - 用户喜欢这部电影的哪些方面？
   - 用户对这部电影有哪些不满？
   - 有什么值得注意的模式或趋势？

5. **行动建议**：基于分析结果，提出具体的建议（如果这是一部待上映的电影，可以建议营销策略；如果是已上映的电影，可以总结成功经验或改进方向）

**格式要求：**
- 使用中文书写
- 使用Markdown格式，包括标题、列表、加粗等
- 语言风格专业但不过于学术化，让普通读者也能理解
- 避免简单的数据罗列，要提供分析和解读
- 报告要有逻辑连贯性，各部分之间要有过渡

**输出格式：**
直接输出Markdown格式的报告内容，不要有其他额外文字。

**重要提示：**
请确保回答完整，不要中途截断。如果内容较长，请继续完成所有部分。
"""

        # 调用LLM生成报告
        from openai import OpenAI
        
        client = OpenAI(
            api_key=os.getenv('DEEPSEEK_API_KEY', ''),
            base_url=os.getenv('DEEPSEEK_API_URL', 'https://api.deepseek.com')
        )

        response = client.chat.completions.create(
            model="deepseek-v4-flash",
            messages=[
                {"role": "system", "content": "你是一位专业的电影评论分析专家，擅长生成详细的数据分析报告。请用中文生成报告，并使用Markdown格式展示。请确保回答完整，不要中途截断。"},
                {"role": "user", "content": prompt}
            ],
            max_tokens=8000,
            temperature=0.7
        )

        report = response.choices[0].message.content
        return report

    except Exception as e:
        error_msg = f"报告生成失败: {str(e)}\n\n请检查：\n1. 是否正确配置了DEEPSEEK_API_KEY环境变量\n2. 网络连接是否正常\n3. API密钥是否有效"
        print(error_msg)
        return error_msg
